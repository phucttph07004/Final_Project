<?php
return[
    'role' => [
        'admin' => 2,
        'manager' => 3,
        'teacher' => 4,
        'director'=>5,
    ],
];
?>